/**
 * 
 */
/**
 * 
 */
module sample {
	requires java.desktop;
}